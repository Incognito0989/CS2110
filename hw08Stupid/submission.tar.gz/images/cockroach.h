/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 cockroach cockroach.png 
 * Time-stamp: Monday 11/08/2021, 17:51:30
 * 
 * Image Information
 * -----------------
 * cockroach.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef COCKROACH_H
#define COCKROACH_H

extern const unsigned short cockroach[1850];
#define COCKROACH_SIZE 3700
#define COCKROACH_LENGTH 1850
#define COCKROACH_WIDTH 50
#define COCKROACH_HEIGHT 37

#endif

