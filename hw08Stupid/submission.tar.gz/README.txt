BUTTON_UP == Jump with a gravity effect
BUTTON_DOWN == Crouch
BUTTON_RIGHT == Move right
BUTTOM_LEFT == Move left
BUTTON_SELECT == Restart
BUTTON_START == Start game
BUTTON_A == Start game

GOAL: 
	The goal of this game is to get to exit out the right side of the map.
	There is a block moving up and down that will crush or prevet you from proceeding.
	There is a bullet trying to murder uuuuuuuu ahhhhh.