/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 picha picha.jpg 
 * Time-stamp: Tuesday 11/09/2021, 05:58:06
 * 
 * Image Information
 * -----------------
 * picha.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PICHA_H
#define PICHA_H

extern const unsigned short picha[400];
#define PICHA_SIZE 800
#define PICHA_LENGTH 400
#define PICHA_WIDTH 20
#define PICHA_HEIGHT 20

#endif

