/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x27 bckcut bckcut.jpg 
 * Time-stamp: Tuesday 11/09/2021, 18:25:11
 * 
 * Image Information
 * -----------------
 * bckcut.jpg 240@27
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BCKCUT_H
#define BCKCUT_H

extern const unsigned short bckcut[6480];
#define BCKCUT_SIZE 12960
#define BCKCUT_LENGTH 6480
#define BCKCUT_WIDTH 240
#define BCKCUT_HEIGHT 27

#endif

